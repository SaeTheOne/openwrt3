package Unicode::Normalize;

use 5.006;
use strict;
use warnings;
use Carp;

no warnings 'utf8';

our $VERSION = '1.32';
our $PACKAGE = __PACKAGE__;

our @EXPORT = qw( NFC NFD NFKC NFKD );
our @EXPORT_OK = qw(
    normalize decompose reorder compose
    checkNFD checkNFKD checkNFC checkNFKC check
    getCanon getCompat getComposite getCombinClass
    isExclusion isSingleton isNonStDecomp isComp2nd isComp_Ex
    isNFD_NO isNFC_NO isNFC_MAYBE isNFKD_NO isNFKC_NO isNFKC_MAYBE
    FCD checkFCD FCC checkFCC composeContiguous splitOnLastStarter
    normalize_partial NFC_partial NFD_partial NFKC_partial NFKD_partial
);
our %EXPORT_TAGS = (
    all       => [ @EXPORT, @EXPORT_OK ],
    normalize => [ @EXPORT, qw/normalize decompose reorder compose/ ],
    check     => [ qw/checkNFD checkNFKD checkNFC checkNFKC check/ ],
    fast      => [ qw/FCD checkFCD FCC checkFCC composeContiguous/ ],
);


                             # No EBCDIC support on early perls
*to_native = ($::IS_ASCII || $] < 5.008)
             ? sub { return shift }
             : sub { utf8::unicode_to_native(shift) };

*from_native = ($::IS_ASCII || $] < 5.008)
             ? sub { return shift }
             : sub { utf8::native_to_unicode(shift) };

sub dot_t_pack_U {
    return pack('U*', map { to_native($_) } @_);
}

sub dot_t_unpack_U {

    # The empty pack returns an empty UTF-8 string, so the effect is to force
    # the shifted parameter into being UTF-8.  This allows this to work on
    # Perl 5.6, where there is no utf8::upgrade().
    return map { from_native($_) } unpack('U*', shift(@_).pack('U*'));
}

sub get_printable_string ($) {
    use bytes;
    my $s = shift;

    # DeMorgan's laws cause this to mean ascii printables
    return $s if $s =~ /[^[:^ascii:][:^print:]]/;

    return join " ", map { sprintf "\\x%02x", ord $_ } split "", $s;
}

sub ok ($$;$) {
    my $count_ref = shift;  # Test number in caller
    my $p = my $r = shift;
    my $x;
    if (@_) {
        $x = shift;
        $p = !defined $x ? !defined $r : !defined $r ? 0 : $r eq $x;
    }

    print $p ? "ok" : "not ok", ' ', ++$$count_ref, "\n";

    return if $p;

    my (undef, $file, $line) = caller(1);
    print STDERR "# Failed test $$count_ref at $file line $line\n";

    return unless defined $x;

    print STDERR "#      got ", get_printable_string($r), "\n";
    print STDERR "# expected ", get_printable_string($x), "\n";
}

require Exporter;


our @ISA = qw(Exporter);
use XSLoader ();
XSLoader::load( 'Unicode::Normalize', $VERSION );



sub FCD ($) {
    my $str = shift;
    return checkFCD($str) ? $str : NFD($str);
}

our %formNorm = (
    NFC  => \&NFC,	C  => \&NFC,
    NFD  => \&NFD,	D  => \&NFD,
    NFKC => \&NFKC,	KC => \&NFKC,
    NFKD => \&NFKD,	KD => \&NFKD,
    FCD  => \&FCD,	FCC => \&FCC,
);

sub normalize($$)
{
    my $form = shift;
    my $str = shift;
    if (exists $formNorm{$form}) {
	return $formNorm{$form}->($str);
    }
    croak($PACKAGE."::normalize: invalid form name: $form");
}


sub normalize_partial ($$) {
    if (exists $formNorm{$_[0]}) {
	my $n = normalize($_[0], $_[1]);
	my($p, $u) = splitOnLastStarter($n);
	$_[1] = $u;
	return $p;
    }
    croak($PACKAGE."::normalize_partial: invalid form name: $_[0]");
}

sub NFD_partial ($) { return normalize_partial('NFD', $_[0]) }
sub NFC_partial ($) { return normalize_partial('NFC', $_[0]) }
sub NFKD_partial($) { return normalize_partial('NFKD',$_[0]) }
sub NFKC_partial($) { return normalize_partial('NFKC',$_[0]) }


our %formCheck = (
    NFC  => \&checkNFC, 	C  => \&checkNFC,
    NFD  => \&checkNFD, 	D  => \&checkNFD,
    NFKC => \&checkNFKC,	KC => \&checkNFKC,
    NFKD => \&checkNFKD,	KD => \&checkNFKD,
    FCD  => \&checkFCD, 	FCC => \&checkFCC,
);

sub check($$)
{
    my $form = shift;
    my $str = shift;
    if (exists $formCheck{$form}) {
	return $formCheck{$form}->($str);
    }
    croak($PACKAGE."::check: invalid form name: $form");
}

1;
__END__

