#include <asm-generic/emergency-restart.h>
